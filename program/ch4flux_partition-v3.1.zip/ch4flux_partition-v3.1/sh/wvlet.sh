#! /bin/tcsh -f
# Time-stamp: <21/02/15 16:06:21 hiwata>

# Enter the following varibales. 
# WORKDIR: this variable should be set to the full path to your ch4flux_partition-v3.1
# directory, e.g., /home/hiwata/ch4flux_partition-v3.1
set WORKDIR = /data1/study4/observation3/swl/analysis/ch4flux_partition-v3.1
# DATA: data directories. Multiple data directories can be set for DATA variable,
# e.g., ( 20160823 20160907 20160928 ).
set DATA = ( 20160823 )
# DT: time interval of time-series data in second (e.g., 10Hz --> 0.1, 20Hz --> 0.05)
set DT = 0.1
# ANALYZER: CH4 analyzer type ("open" for an open-path analyzer, "closed" for a closed-path analyzer)
# sample 20120823 data is for a closed-path analyzer, and 20160823 data is for an open-path analyzer
set ANALYZER = open

cd $WORKDIR
foreach data ( $DATA )
  echo $data
##Get a list of data
  set DATFIL = `ls data/$data/*.dat | awk -F/ '{print $3}'`
  if ( -d wvlet/coef/$data/ ) then
  else
    mkdir -p wvlet/coef/$data/
  endif
  if ( -d fig/raw/$data/ ) then
  else
    mkdir -p fig/raw/$data/
  endif
  if ( -d wvlet/spec/$data/ ) then
  else
    mkdir -p wvlet/spec/$data/
  endif
##Calculation of each data run
  foreach datfil ( $DATFIL )
    echo $datfil
    cp data/$data/$datfil temp.dat
    set NUM = `wc temp.dat | awk '{print $1}'`
    echo "      parameter ( spl_num =" $NUM ", dt =" $DT ")" > fort/param1
####Wavelet transform
    if ( $ANALYZER == "open" ) then
      gfortran fort/wavelet_o.f ; ./a.out
    else if ( $ANALYZER == "closed" ) then
      grep $datfil data/met/$data\met.txt | awk '{print $2,$3}' > met.txt
      gfortran fort/wavelet_c.f ; ./a.out
    else
      echo "A variable ANALYZER was not set properly."
    endif
    mv wvlet.txt wvlet/coef/$data/wvlet-$datfil
    mv spec.txt wvlet/spec/$data/spec-$datfil
    echo 'set title "'$datfil'"' > gp/time.gp
    if ( $ANALYZER == "open" ) then
      gnuplot gp/ts_o.gp > fig/raw/$data/$datfil.jpg
    else if ( $ANALYZER == "closed" ) then
      gnuplot gp/ts_c.gp > fig/raw/$data/$datfil.jpg
    endif
    echo " "
  end
end

rm a.out temp.dat met.txt temp.txt
