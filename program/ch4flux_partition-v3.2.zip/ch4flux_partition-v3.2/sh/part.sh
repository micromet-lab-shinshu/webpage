#! /bin/tcsh -f
# Time-stamp: <22/04/09 14:23:41 hiwata>

# WORKDIR: this variable should be set to the full path to your ch4flux_partition-v3.1
# directory, e.g., /home/hiwata/ch4flux_partition-v3.1
set WORKDIR = /data1/study4/observation3/swl/analysis/ch4flux_partition-v3.2
# Enter these two varibales.
# DIR: wvlet data directory
# Zm: Measurement height in meter
# d: zero-plane displacement
# DT: time interval of time-series data in second (e.g., 10Hz --> 0.1, 20Hz --> 0.05 )
set DIR = ( 20160823 )
set Zm = 3.17
set d = 0.0
set DT = 0.1
# Change the following variables, if necessary
# LB: Lower boudary of normalized frequency to be included in the partitioning
# UB: Upper boudary of normalized frequency to be included in the partitioning
# SD_TCH: RMSD around T-CH4 line
# SD_QCH: RMSD around Q-CH4 line
# SD_QT: RMSD around Q-T line
set LB = 0.003
set UB = 1
set SD_TCH = 0.000859
set SD_QCH = 0.000803
set SD_QT = 0.0876

cd $WORKDIR
echo "qt tch qch" > rmsd.txt
echo $SD_QT $SD_TCH $SD_QCH >> rmsd.txt
foreach dir ( $DIR )
  echo $dir
  set FILE = `ls wvlet/coef/$dir/*.dat | awk -F/ '{print $4}'`
  echo "      parameter ( zm = " $Zm ", d = " $d ")" > fort/param2
  echo "      parameter ( lb = " $LB ", ub = " $UB ")" > fort/param3
  echo "      parameter ( sd_tch = " $SD_TCH ", sd_qch = " $SD_QCH ")" > fort/param4
  echo "      parameter ( sd_qt = " $SD_QT ")" > fort/param5
  if ( -d fig/coef/$dir ) then
  else
    mkdir fig/coef/$dir
  endif
  if ( -d results/pickup/$dir ) then
  else
    mkdir results/pickup/$dir
  endif
  if ( -d results/filt/$dir ) then
  else
    mkdir results/filt/$dir
  endif

  echo "file_name total_CH4_flux diffusive_CH4_flux_based_on_T-CH4 bubble_CH4_flux_based_on_T-CH4 diffusive_CH4_flux_based_on_H2O-CH4 bubble_CH4_flux_based_on_H2O-CH4 low-frequency_component_CH4_flux RMSD_T-CH4 RMSD_Q-CH4 RMSD_Q-T slope_tch slope_qch slope_qt slope_cch" > flux.txt
  echo "file_name diffusive_flux_based_on_T-CH4 bubble_CH4_flux_based_on_T-CH4 diffusive_flux_based_on_H2O-CH4 bubble_CH4_flux_based_on_H2O-CH4" > rerror.txt
  foreach file ( $FILE )
    echo $file
    cp wvlet/coef/$dir/$file temp1.txt
    set NUM = `wc temp1.txt | awk '{print $1}'`
    echo "      parameter ( ni = " $NUM ", dt = " $DT ")" > fort/param6
    echo "u  w  T  q  CO2  CH4" > temp2.txt
    more temp1.txt >> temp2.txt
    gfortran fort/pickup.f -o pickup.out
    ./pickup.out
    Rscript R/robust.R
    mv wt.jpeg fig/coef/$dir/$file.jpeg
    mv wt2.jpeg fig/coef/$dir/$file-2.jpeg
    mv temp3.txt results/pickup/$dir/$file
    echo $file > date.txt
    gfortran fort/filter.f -o filter.out
    ./filter.out
    paste date.txt part.txt >> flux.txt
    gfortran fort/ranerror.f -o ranerror.out
    ./ranerror.out
    paste date.txt error.txt >> rerror.txt
    mv filter.txt results/filt/$dir/$file
  end

  mv flux.txt results/flux/flux$dir.txt
  mv rerror.txt results/flux/rerror$dir.txt
end

rm filter.out pickup.out ranerror.out date.txt out?.txt part.txt error.txt winddata temp?.txt rmsd.txt
