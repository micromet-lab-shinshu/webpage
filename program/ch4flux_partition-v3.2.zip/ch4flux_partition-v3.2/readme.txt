This program performs a partitioning of eddy-covariance methane fluxes
from a lake into diffusive and ebullitive fluxes. The program is designed
to be run on a linux computer or in any linux-like environments (such as
Ubuntu/Debian app on Windows 10).
Please read the following paper for the theoretical background of the
partitioning.
------------------------------------------------------------------------------
Iwata, H., Hirata, R., Takahashi, Y., Miyabara, Y., Itoh, M., and Iizuka, K.,
2018. Partitioning eddy-covariance methane fluxes from a shallow lake into
diffusive and ebullitive fluxes. Boundary-Layer Meteorology 169, 413-428.
------------------------------------------------------------------------------
This program is still being developed to be performed in various environments.
Please let the author know if any errors arise in running the program.
Thanks!
                   Program author: Hiroki Iwata (hiwata@shinshu-u.ac.jp)

0. Program development and modification
- v0.1: published on July 31st, 2018
- v0.2: with minor change of readme file
- v1.0: point-by-point conversions of sonic temperature and gas densities were added.
- v1.1: minor modification to wvlet.sh to adjust for the Cygwin environment (December, 2019)
- v2.0: random error calculation based on Finkelstein & Sims (2001) was included (May 11, 2020).
- v3.0: calculation for a closed-path CH4 analyzer was included (September 28, 2020).
- v3.1: plotting raw time series data was added, output of spectra was added (February 15, 2021).
- v3.2: zero-plane displacement was added for non-lake ecosystems,
        in some parts fixed 10Hz was assumed --> fixed (April 9, 2022)

1. Prerequisite packages
 - tcsh
 - gfortran
 - r-base
 - r-cran-foreign
 - r-cran-mass

2. Usage of the program

   i) Unzip the downloaded file and place it in an arbitrary directory.

  ii) The program includes sample data stored in "sample/data" directory. First thing you
      should try is to run the program with the sample data to confirm that the
      calculation is done correctly in your own environment.

      To do so, open sh/wvlet.sh and sh/part.sh with a text editor and set WORKDIR to
      the full path to your own ch4flux_partition-v3.1 directory. The sample data in 20160823
      directory are for an open-path CH4 analyzer, so the ANALYZER variable in sh/wvlet.sh
      should be set to "open" in the test calculation. Similarly, the sample data in 20120823
      directory are for a closed-path analyzer, so the ANALYZER variable should be set to "closed".
      Copy the sample raw data in "sample/data" directory to "data" directory in your
      ch4flux_partition-v3.1 directory. Then, run sh/wvlet.sh to perform wavelet transform,
      then run sh/part.sh to perform the flux partitioning. Please note that the shell
      scripts (wvlet.sh and part.sh) should be executable. Check with "ls -l sh/wvlet.sh"
      command, and if it is not, change the permission with "chmod u+x sh/wvlet.sh" command.

      Finally, check if the results you obtain in "wvlet" and "results" directories are the
      same as the data in the corresponding directories in the "sample" directory.

 iii) After confirming that your calculations are correct, try with your own data.
      Store processed data in a subdirectory in "data" directory. The file name should
      have "dat" extension. Note that necessary processing such as spike removal, coordinate
      rotation of three-dimensional sonic data, data synchronization between wind
      and gas density data should be applied before running this program. These preprocessing
      can be done in EddyPro or other flux processing tools.
      Point-by-point conversions of sonic temperature and gas density data are included
      in this program. Because the orthogonal wavelet decomposition is applied, number of
      data up to power of 2 only is used in the calculation.

      Data should include the following variables.

      - For an open-path CH4 analyzer, streamwise wind velocity (m/s), vertical wind velocity (m/s),
        sonic temperature (degC), water vapor density (g/m3), carbon dioxide density (mg/m3),
        methane density (mmol/m3), atmospheric pressure (kPa), and air temperature (degC)
        in this order. The last three data should be obtained from the open-path CH4 analyzer.

      - For a closed-path analyzer, streamwise wind velocity (m/s), vertical wind velocity (m/s),
        sonic temperature (degC), water vapor density (g/m3), carbon dioxide density (mg/m3),
        methane concentration (ppm), and water vapor concentration from the closed-path analyzer
        (ppm) in this order. The last variable is used to convert the moist air-based CH4
        concentration to dry air-based one.
        For a closed-path analyzer only, mean air temperature and atmospheric pressure data are
        also needed and they should be stored in "data/met" directory. These data are used
        in the point-by-point WPL conversion. 

      Note that the units need to be converted in advance. No header information should be
      included in the data files.
      Please see the sample data as the reference when you prepare the data (20160823 for
      an open-path analyzer and 20120823 for a closed-path analyzer).

  iv) Open sh/wvlet.sh with a text editor and enter DATA, DT, and ANALYZER variables. Run
      the wvlet.sh script to perform wavelet transform. The results will be stored in "wvlet"
      directory. The "coef" subdirectory includes wavelet coefficients used subsequently in
      the partitioning in the following step.

      The "spec" subdirectory includes wavelet covariances integrated for each time scale.
      The data columns indicate time scale (s), mean wind speed (m/s), w-T covariance, w-q
      covariance, w-CO2 covariance, and w-CH4 covariance. The covariances are normalized with
      the total covariance. These data can be used to adjust the LB and UB parameters in
      sh/part.sh, when necessary.

      The "fig/raw" subdirectory includes raw data plots, which can be used to detect any erroneous
      raw data. Please note that this program does not include data quality check procedure, thus
     it should be checked by users using other flux processing tools.

   v) Open sh/part.sh with a text editor and enter DIR and Zm variables. Run
      the part.sh script to perform the flux partitioning. Partitioned fluxes will be stored
      in "results/flux" directory. Flux files include total and partitioned fluxes with supplemental
      information. Rerror files include random flux errors for the partitioned fluxes.
      Please note that in the flux partitioning, low-frequency components are not partitioned. Rather
      they are separately written out in the "low-frequency_component" column. This means that
      the total flux equals to diffusive flux + bubble flux + low-frequency_component.

      The scatterplot of wavelet coefficients are produced in the "fig/coef" subdirectory.
      If necessary, edit "R/robust.R" file to adjust the x and y ranges. To do so, for example,
      xlim and ylim parameters should be changed in plot(wt$T,wt$CH4, xlim=c(-4,4), ylim=c(-0.05,0.05)).

      I recommend to examine stored data in "wvlet/spec" and "results/flux" directory and
      change LB, UB, SD_TCH, SD_QCH, and SD_QT variables in the sh/part.sh and run
      the part.sh again.
      I recommend to check the RMSD_Q-CH4 (or RMSD_T-CH4) in the flux file. The minimum value
      in this data column can be set to SD_QCH, which can be interpreted as an appropriate bound to
      separate the wavelet coefficients into diffusion and ebullition for your data.
